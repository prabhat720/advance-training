package com.prabhat.training;

public class Flute extends Instrument {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Flute is playing  toot toot toot toot");
	}

}
