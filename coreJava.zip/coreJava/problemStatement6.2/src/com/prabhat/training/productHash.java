package com.prabhat.training;

import java.util.Hashtable;
import java.util.Scanner;

public class productHash {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Hashtable<String,String> hm=new Hashtable<String,String>();
		System.out.println("enter the product id and name;");
		for(int i=0;i<10;i++)
		{
			hm.put(scan.next(),scan.next());
		}
		System.out.println("the product list is:");
		System.out.println(hm);
		System.out.println("enter the product id to be removed:");
		String id = scan.next();
		hm.remove(id);
		System.out.println("item removed");
		System.out.println("the product list is:");
		System.out.println(hm.toString());
		System.out.println("enter the product id to be searched:");
		String sid=scan.next();
		if(hm.containsKey(sid))
		{
			System.out.println(hm.get(sid));
		}
		else {
			System.out.println("do not exist");
		}
	}
}
