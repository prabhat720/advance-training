package com.prabhat.training;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class arrayList {

	public static void main(String[] args) {
		ArrayList<String> alist = new ArrayList<String>();
		int n ;
		@SuppressWarnings("resource")
		Scanner scan = new Scanner (System.in);
		n=scan.nextInt();
		System.out.println("Enter the number of Student : ");
		for(int i=0 ;i<n;i++)
		{
			alist.add(scan.next()) ;
		}
		System.out.println("Student list :");
		for (String a:alist)
		{
			System.out.println(a);
		}
		System.out.println(" Enter the name of student to be searched : ");
		String str =scan.next();
		int position = Collections.binarySearch(alist, str);
		System.out.println(" Position of "+ str + " is : "+position );
		
	}
}
