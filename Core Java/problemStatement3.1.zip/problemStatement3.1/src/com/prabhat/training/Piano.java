package com.prabhat.training;

public class Piano extends Instrument {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("Piano is playing  tan tan tan tan");
	}

}
