package com.prabhat.training;

import java.util.HashMap;
import java.util.Map;

public class decimalProblem {

	public static String calculateFraction(int num, int den)
    {
        if (num == 0)
            return "0"; // if numerator is zero
        if (den == 0)
            return ""; // if denominator is zero
 
        // StringBuilder
 
        StringBuilder result = new StringBuilder();
        if ((num < 0) ^ (den < 0))
            result.append("-"); // check -ve sign
 
        // absolute values of numerator and denominator
 
        num = Math.abs(num);
        den = Math.abs(den);
 
        long quo = num / den; // Quotient
        long rem = num % den * 10; // calculating remainder
 
        result.append(
            String.valueOf(quo)); // appending quotient
        if (rem == 0)
            return result
                .toString(); // return if remainder is 0
 
        // if remainder is not zero, continue
 
        result.append(".");
        Map<Long, Integer> m
            = new HashMap<>(); 
 
        while (rem != 0) {
 
            if (m.containsKey(rem)) {
 
                
                int index = m.get(rem);
                String part1 = result.substring(0, index);
                String part2 = "("
                               + result.substring(
                                   index, result.length())
                               + ")";
                return part1 + part2;
            }
 
         
            m.put(rem, result.length());
            quo = rem / den;
            result.append(String.valueOf(quo));
            rem = (rem % den) * 10;
        }
        return result.toString();
    }
 
    public static void main(String[] args)
    {
        int num = 113;
        int den = 56;
 
        String resString1 = calculateFraction(num, den);
 
        num = 1;
        den = 4;
 
        String resString2 = calculateFraction(num, den);
 
        System.out.println(resString1);
        System.out.println(resString2);
    }
}
