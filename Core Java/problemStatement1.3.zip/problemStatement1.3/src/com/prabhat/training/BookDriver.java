package com.prabhat.training;

import java.util.Scanner;

public class BookDriver {
	
	public static void main(String[] args) {
		createBooks();
		
	}
	
	
	
	public static  void createBooks()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of Books");
		int n= sc.nextInt();
	    Book[] book=new Book[n];
	    
	    book[0] = new Book("Java Programing ", 350.50);
	      book[1] = new Book("Let Us C", 200.00);
	   showBooks(book);
	    
	    
	  }
	public static void showBooks(Book[] book)
	 {
		 System.out.println("Title"+ "           "+ "Price" );
		for(int i = 0; i<book.length; i++) {
			book[i].display();
			   }
		
		 
	 }
	 
	
		


}
