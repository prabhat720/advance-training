package com.prabhat.training;

import java.util.Scanner;
import java.util.Vector;

public class coinChangeProblem {
	// All denominations of Indian Currencies 
    static int deno[] = {1,2,5,10,20,50,100,500,2000};
    static int n = deno.length;
  
    static void findMin(int V)
    {
        //  result 
        Vector<Integer> ans = new Vector<>();
  
        // Traverse throughout all denomination 
        for (int i = n - 1; i >= 0; i--)
        {
            // search denominations 
            while (V >= deno[i]) 
            {
                V -= deno[i];
                ans.add(deno[i]);
            }
        }
  
        // Print the  results
        for (int i = 0; i < ans.size(); i++)
        {
            System.out.print(
              "Rs." +ans.elementAt(i)+""+"*1 ");
        }
    }
  
    // Drive code 
    public static void main(String[] args) 
    {
    	Scanner S=new Scanner(System.in);
		System.out.println("Enter The currency :");
        int n= S.nextInt(); 
        System.out.print(
            "BeakDown"
            +"of change for " + n + ": ");
        findMin(n);
    }
}
